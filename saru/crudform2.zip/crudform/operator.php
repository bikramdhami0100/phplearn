<?php
echo"hello";
?> 


 <!-- PHP OPERATOR -->
 <!-- 1.Arithmatic operator -->
 <?php
 $a=2;
 $b=3;
 echo"sum of a+b,result is".($a+$b)."<br>";
$a+=2;
echo"for a,the value is".$a."<br>";
?>



