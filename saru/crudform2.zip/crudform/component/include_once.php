<!-- for include-once statement -->

<?php
echo"<p>copyright and copy;2022 fwu.edu.np</p>";
?>

<html>
    <head>
        <title> welcome to cdcsit</title>
    </head>
    <body>
    <h1>welcome to cdcsit</h1>
    <?php
    include_once'footer.php';
    ?>
    </body>
</html>